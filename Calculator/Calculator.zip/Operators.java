package com.codingdojo.calculator;

public interface Operators {
    void performOperation ();
    double getResult ();
}