package com.codingdojo.objectmaster;

public class Wizard extends Human {

	public Wizard() {
		super.setHealth(50);
		super.setIntelligence(8);
	}
	
	public void healHuman(Human target) {
		target.setHealth(target.getHealth()+(this.getIntelligence()));
		System.out.println("You have healed "+target.getHealth());
	}
	
	public void fireballHuman(Human target) {
		target.setHealth(target.getHealth()+(this.getIntelligence()*3));
		System.out.println("You have healed "+target.getHealth());
	}
}
