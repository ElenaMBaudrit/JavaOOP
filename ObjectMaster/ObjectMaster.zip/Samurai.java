package com.codingdojo.objectmaster;

public class Samurai extends Human {
	
	public static int samurais = 0;
	
	public int getSamurais() {
		return Samurai.samurais;
	}

	public Samurai() {
		super.setHealth(200);
		Samurai.samurais =+1 ;
	}
	
	public void deathBlowHuman (Human target) {
		target.setHealth(target.getHealth() - (target.getHealth()));
		this.setHealth(this.getHealth() /2);
		System.out.println("Samurai: you have killed one person. Now you've received "+this.getHealth()+ "health damage.");
	}
	public void meditateHuman (Human target) {
		this.setHealth(this.getHealth() + (this.getHealth()/2));
		System.out.println("Meditation fills the Soul and let the Samurai heal up to " +this.getHealth());
	}
}