package com.codingdojo.objectmaster;

public class Human{
	private int healthLevel;
	private int strengthLevel;
	private int stealthLevel;
	private int intelligenceLevel;
	
	public Human(){
		healthLevel = 100;
		strengthLevel = 3;
		stealthLevel = 3;
		intelligenceLevel = 3;

	}
	public void displayHealth() {
		System.out.println("Health level starts at: " + healthLevel);
	}
	public void displayStrength() {
		System.out.println("Strength level starts at: " + strengthLevel);
	}
	public void displayStealth() {
		System.out.println("Stealth level starts at: " + stealthLevel);
	}
	public void displayIntelligence() {
		System.out.println("Intelligence level starts at: " + intelligenceLevel);
	}
	
	public int getHealth() {
		return healthLevel;
	}
	public void setHealth(int healthVal) { //this is void. Does not return anything.
		healthLevel = strengthLevel;;
	}
	
	public int getStrength() {
		return strengthLevel;
	}
	public void setStrength(int strengthVal) {
		strengthLevel = strengthVal;
	}
	
	public int getStealth() {
		return stealthLevel;
	}
	public void setStealth(int stealthVal) {
		stealthLevel = stealthVal;
	}
	
	public int getIntelligence() {
		return intelligenceLevel;
	}
	public void setIntelligence(int intelligenceVal) {
		intelligenceLevel = intelligenceVal;
	}
	
	public void attackHuman (Human target) {
		target.setHealth(target.getHealth()-this.getStrength());
		System.out.println("You attacked, and the other lost "+target.getHealth()+"health.");
	}
}