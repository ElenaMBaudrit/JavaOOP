package com.codingdojo.objectmaster;

public class Ninja extends Human {

	public Ninja() {
		super.setStealth(10);
	}
	
	public void stealHuman (Human target) {
		target.setHealth(target.getHealth()-(this.getStealth()));
		this.setHealth(this.getHealth() + (this.getStealth()));
		System.out.println("Target has received "+this.getStealth()+ "health damage.");
	}
	
	public void runAway(Human target) {
		this.setHealth(-10);
		System.out.println("You ran away, and lost "+this.getHealth()+"health.");
	}
}