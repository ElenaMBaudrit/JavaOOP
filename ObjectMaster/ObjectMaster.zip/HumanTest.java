package com.codingdojo.objectmaster;

public class HumanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub		Human h = new Human();
		Human h = new Human();
		Human h1 = new Human ();
		Human h2 = new Human ();
		h.attackHuman(h1);
		h1.attackHuman(h2);
		h2.attackHuman(h);
		
		Ninja n = new Ninja();
		Ninja n1 = new Ninja();
		Ninja n2 = new Ninja();
		n.stealHuman(n);
		n1.stealHuman(n2);
		n2.stealHuman(n);
		n.runAway(n1);
		n1.runAway(n2);
		n2.runAway(n);
		
		Wizard w = new Wizard();
		Wizard w1 = new Wizard();
		Wizard w2 =  new Wizard();
		w.healHuman(w1);
		w1.healHuman(w2);
		w2.healHuman(w);
		w.fireballHuman(n);
		w1.fireballHuman(n1);
		w2.fireballHuman(n2);
		
		Samurai s = new Samurai();
		Samurai s1 = new Samurai();
		Samurai s2 = new Samurai();
		s.deathBlowHuman(s1);
		s1.deathBlowHuman(s2);
		s2.deathBlowHuman(s2);
		s.meditateHuman(w2);
		s1.meditateHuman(w1);
		s2.meditateHuman(s);
		
	}
}
