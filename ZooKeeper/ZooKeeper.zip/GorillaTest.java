
public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla g = new Gorilla();
		g.throwSomething();
		g.displayEnergy();
		g.throwSomething();
		g.displayEnergy();
		g.throwSomething();
		g.displayEnergy();
		g.eatBananas();
		g.displayEnergy();
		g.eatBananas();
		g.displayEnergy();
		g.climb();
		g.displayEnergy();
	}

}

