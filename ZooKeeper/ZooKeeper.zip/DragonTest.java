
public class DragonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dragon Lizzy = new Dragon();
		Lizzy.attackTown();
		Lizzy.displayEnergy();
		Lizzy.attackTown();
		Lizzy.displayEnergy();
		Lizzy.attackTown();
		Lizzy.displayEnergy();
		Lizzy.eatHumans();
		Lizzy.displayEnergy();
		Lizzy.eatHumans();
		Lizzy.displayEnergy();
		Lizzy.fly();
		Lizzy.displayEnergy();
		Lizzy.fly();
		Lizzy.displayEnergy();	
	}
}
