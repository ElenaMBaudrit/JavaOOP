package com.codingdojo.pokemon;

public class PokeTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pokemon p1 = new Pokemon("Ditto", 70, "Normal");
		Pokemon p2 = new Pokemon("Swoobat", 150, "Psychic");
		Pokemon p3 = new Pokemon("Spiritomb", 170, "Ghost");
		System.out.println(Pokemon.numberOfPokemons);
	}

}
